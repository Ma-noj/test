package edu.clarivate.carapp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Bike {
	@Id
	private int bikeId;
	private String bikeName;
	private String bikeBrand;
	private String bikeColour;
	private double bikePrice;
	private int bikeCC;

	public String getBikeBrand() {
		return bikeBrand;
	}

	public void setBikeBrand(String bikeBrand) {
		this.bikeBrand = bikeBrand;
	}

	public int getBikeId() {
		return bikeId;
	}

	public void setBikeId(int bikeId) {
		this.bikeId = bikeId;
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public String getBikeColour() {
		return bikeColour;
	}

	public void setBikeColour(String bikeColour) {
		this.bikeColour = bikeColour;
	}

	public double getBikePrice() {
		return bikePrice;
	}

	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}

	public int getBikeCC() {
		return bikeCC;
	}

	public void setBikeCC(int bikeCC) {
		this.bikeCC = bikeCC;
	}

}
